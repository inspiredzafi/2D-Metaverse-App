import React from 'react'
import './Playfield.css'

const Playfield = () => {
  return (
    <canvas id="playfield" height={600} width={1100}></canvas>
  )
}

export default Playfield