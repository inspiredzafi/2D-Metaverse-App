import React from 'react'
import './ActiveCall.css'

const ActiveCall = () => {
  return (
    <div id='activeCall'>
        <h2 >Active Call</h2>
        <div id="videoContainer">
            <video src="" id='remoteVideo'></video>
            <video src="" id='localVideo'></video>
        </div>
    </div>
  )
}

export default ActiveCall